using System.Reflection;
using System.Runtime.CompilerServices;
using System;


[assembly: AssemblyTitle("Starksoft.Net.Ftp")]
[assembly: AssemblyDescription("Starksoft FTP/FTPS client component library")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Starksoft, LLC")]
[assembly: AssemblyProduct("Starksoft FTP/FTPS Client Library")]
[assembly: AssemblyCopyright("Copyright 2009,2010")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("1.0.158.0")]
[assembly: AssemblyFileVersion("1.0.158.0")]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyName("")]


[assembly: System.Runtime.InteropServices.ComVisible(false)]
[assembly: CLSCompliant(true)]
namespace Starksoft.Net.Ftp
{ }
